#ifndef MECRC_H
#define MECRC_H

#include <stdint.h>

extern uint16_t MeCRC16(uint16_t n, uint8_t m);

#endif